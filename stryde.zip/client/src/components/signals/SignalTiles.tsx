import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

interface CardiacDriftData {
  viable: boolean
  reason?: string
  averageDrift?: number
  flag?: string
  worstRun?: {
    name: string
    date: string
    drift: number
  }
  mostRecentRun?: {
    name: string
    date: string
    drift: number
    efFirstHalf: number
    efLastHalf: number
  } | null
}

interface TrainingLoadData {
  severity: number
  flag: string
  highLoadDayCount: number
  consecutiveCount: number
  isActive: boolean
  lastHighLoadDay: string
  lastHighLoadDayISO: string | null
  pattern: string
  recentDays: string[]
  sevenDayTotalTrimp: number
  mostRecentTrimp: number
  elevatedDaysThisWeek: number
  weeklyWatchThreshold: number
  highVolume: boolean
}

interface SessionSpikeData {
  viable: boolean
  reason?: string
  flag?: string
  spikePercentage?: number
  spikeRun?: { name: string; distance: number; date: string }
  baselineRun?: { name: string; distance: number; date: string }
}

const formatDate = (dateStr: string) =>
  new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })

// Stripe/badge color keyed by semantic status, not per-signal -- so "GOOD"
// on drift and "CLEAR" on training load render identically (both green),
// only the label text differs.
const STATUS_COLOR = {
  good: '#4ade80',
  watch: '#f59e0b',
  high: '#f87171',
}

const STATUS_BADGE_CLASS = {
  good: 'bg-[#0a2010] text-[#4ade80]',
  watch: 'bg-[#2a1a00] text-[#f59e0b]',
  high: 'bg-[#2a0a0a] text-[#f87171]',
}

interface TileData {
  key: string
  label: string
  primary: string
  status: 'good' | 'watch' | 'high'
  badgeLabel: string
  detailTitle: string
  detailBody: string
  detailFootnote?: string
}

function Tile({ tile, isOpen, onToggle }: { tile: TileData; isOpen: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      className="text-center px-1 py-1.5 w-full"
    >
      <div className="flex items-center justify-center gap-1.5 mb-2">
        <span
          className="w-1.5 h-1.5 rounded-full inline-block"
          style={{ backgroundColor: STATUS_COLOR[tile.status] }}
        />
        <p className="text-[10px] text-[#999999] uppercase tracking-wide">{tile.label}</p>
      </div>
      <p className="text-xl font-medium text-[#ededed] leading-none">{tile.primary}</p>
      <p className="text-[10px] font-medium mt-1" style={{ color: STATUS_COLOR[tile.status] }}>
        {tile.badgeLabel}
      </p>
      <ChevronDown
        size={12}
        className={`mx-auto mt-1.5 text-[#555555] transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
      />
    </button>
  )
}

export function SignalTiles({
  cardiac,
  trainingLoad,
  spike,
}: {
  cardiac: CardiacDriftData | null
  trainingLoad: TrainingLoadData | null
  spike: SessionSpikeData | null
}) {
  const [openKey, setOpenKey] = useState<string | null>(null)

  const tiles: TileData[] = []

  if (cardiac?.viable) {
    const status = cardiac.flag === 'stable' ? 'good' : cardiac.flag === 'significant' ? 'high' : 'watch'
    tiles.push({
      key: 'drift',
      label: 'Drift',
      primary: `${Math.round(cardiac.averageDrift! * 10) / 10}%`,
      status,
      badgeLabel: status === 'good' ? 'GOOD' : status === 'high' ? 'HIGH' : 'WATCH',
      detailTitle: 'Cardiac drift',
      detailBody: cardiac.mostRecentRun
        ? `${Math.round(cardiac.mostRecentRun.drift * 10) / 10}% drift · most recent, ${formatDate(cardiac.mostRecentRun.date)}`
        : `${cardiac.flag}, 7-day average`,
      detailFootnote: cardiac.worstRun
        ? `${Math.round(cardiac.worstRun.drift * 10) / 10}% worst this week (${formatDate(cardiac.worstRun.date)}) · Based on velocity + HR stream`
        : 'Based on velocity + HR stream',
    })
  }

  if (trainingLoad) {
    const status = trainingLoad.highVolume ? 'watch' : 'good'
    tiles.push({
      key: 'load',
      label: 'Load',
      primary: `${Math.round(trainingLoad.sevenDayTotalTrimp)}`,
      status,
      badgeLabel: status === 'good' ? 'CLEAR' : 'WATCH',
      detailTitle: 'Training load',
      detailBody: `${Math.round(trainingLoad.sevenDayTotalTrimp)} TRIMP, 7-day total · ${trainingLoad.elevatedDaysThisWeek} of 7 days elevated effort or higher`,
      detailFootnote: `${trainingLoad.highLoadDayCount} high-load days in last 10 · Based on heart-rate-derived TRIMP`,
    })
  }

  if (spike?.viable) {
    const isClear = spike.flag === 'safe'
    tiles.push({
      key: 'spike',
      label: 'Spike',
      primary: isClear ? '—' : `${Math.round(spike.spikePercentage!)}%`,
      status: isClear ? 'good' : 'watch',
      badgeLabel: isClear ? 'CLEAR' : 'WATCH',
      detailTitle: 'Session spike',
      detailBody: isClear
        ? 'No outlier sessions detected'
        : `${spike.spikeRun!.name} · ${spike.spikeRun!.distance}mi, ${Math.round(spike.spikePercentage!)}% above your 30-day baseline`,
      detailFootnote: isClear
        ? 'Based on your trailing 30-day longest run'
        : `Compared to your ${spike.baselineRun!.distance}mi longest run in the prior 30 days`,
    })
  }

  const openTile = tiles.find(t => t.key === openKey)

  return (
    <div className="rounded-2xl bg-[#161616] p-3.5">
      <div className="grid grid-cols-3 divide-x divide-[#1f1f1f]">
        {tiles.map(tile => (
          <Tile
            key={tile.key}
            tile={tile}
            isOpen={openKey === tile.key}
            onToggle={() => setOpenKey(openKey === tile.key ? null : tile.key)}
          />
        ))}
      </div>

      <div
        className={`transition-all duration-200 ease-out overflow-hidden ${
          openTile ? 'max-h-40 opacity-100 mt-3 pt-3 border-t border-[#1f1f1f]' : 'max-h-0 opacity-0'
        }`}
      >
        {openTile && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-[#ededed]">{openTile.detailTitle}</p>
              <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${STATUS_BADGE_CLASS[openTile.status]}`}>
                {openTile.badgeLabel}
              </span>
            </div>
            <p className="text-[13px] text-[#999999] mb-1.5">{openTile.detailBody}</p>
            {openTile.detailFootnote && (
              <p className="text-[11px] text-[#999999]">{openTile.detailFootnote}</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}