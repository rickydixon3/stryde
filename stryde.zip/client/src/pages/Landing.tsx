import { LogoMark } from '../components/Logo'
import { Eye } from 'lucide-react'

const VALUE_PROPS = [
  {
    title: 'Grade-adjusted efficiency',
    body: 'Your pace, adjusted for elevation and normalized to your own heart-rate reserve, computed across the entire run, giving you an accurate efficiency reading.',
  },
  {
    title: 'Cardiac drift, per run',
    body: 'Also known as aerobic decoupling. See exactly how your cardiovascular efficiency holds up from the first half of a run to the last, so you catch fatigue before it shows up in your times.',
  },
  {
    title: 'Training load, backed by data',
    body: 'Computed with TRIMP, a heart-rate-based formula for training stress, grounded in published research and tested against real training history.',
  },
  {
    title: 'Personalized, not generic',
    body: 'Every threshold, effort classification, training load, session spikes, is built from your own historical data, not a fixed number that treats every runner the same.',
  },
  {
    title: 'Backed by real science',
    body: 'Every metric traces back to a real physiological signal: heart rate, pace, and effort, measured and normalized to your own body, not an arbitrary score.',
  },
]

export default function Landing() {
  const handleConnect = () => {
    window.location.href = `${import.meta.env.VITE_API_URL}/auth/strava`
  }

  const handleDemoLogin = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/auth/demo-login`, {
        method: 'POST',
      })

      if (!response.ok) {
        console.error('Demo login failed:', response.status)
        return
      }

      const { token } = await response.json()
      localStorage.setItem('token', token)
      window.location.href = '/'
    } catch (err) {
      console.error('Demo login error:', err)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a]">

      {/* Nav */}
      <div className="max-w-5xl mx-auto px-6 py-6 flex items-center gap-2">
        <LogoMark size={28} />
        <span className="font-medium text-[#ededed]">Stryde</span>
      </div>

      {/* Hero -- plain background, no overlay, own clean space */}
      <div className="max-w-4xl mx-auto px-6 pt-12 pb-16 text-center">
        <h1 className="text-3xl sm:text-4xl font-medium text-[#ededed] mb-4 leading-tight">
        Track your running performance and training load.
        <br />
        Connect with Strava seamlessly.
        </h1>
        <p className="text-base text-[#999999] mb-10 max-w-xl mx-auto">
        Efficiency factor, cardiac drift, and TRIMP-based training load.
        The signals that show what's actually happening in your training.
        </p>

        <div className="flex flex-col items-center">
          <button onClick={handleConnect} className="inline-block">
            <img
              src="/strava-connect-button.svg"
              alt="Connect with Strava"
              className="h-12"
            />
          </button>

          <button
            onClick={handleDemoLogin}
            className="mt-3 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md border border-[#333333] text-sm font-medium text-[#ededed] hover:bg-[#1a1a1a] hover:border-[#444444] transition-colors"
          >
            <Eye size={14} />
            View demo
          </button>
        </div>

        <p className="text-xs text-[#999999] mt-4">
          By connecting, you agree to our{' '}
          <a href="/privacy" className="text-[#378ADD] hover:underline">
            Privacy Policy
          </a>
        </p>
      </div>

      {/* Dashboard preview -- own contained card, full clarity, no overlay */}
      <div className="max-w-5xl mx-auto px-6 pb-24">
        <img
          src="/dashboard-preview.png"
          alt="Stryde dashboard showing efficiency factor trend, cardiac drift, training load, and session spike signals"
          className="w-full rounded-xl border border-[#1f1f1f]"
        />
      </div>

      {/* Value props -- 3-column grid, 5 cards (3 on top, 2 centered below) */}
      <div className="max-w-5xl mx-auto px-6 pb-24">
        <div className="grid sm:grid-cols-3 gap-6">
          {VALUE_PROPS.map((prop) => (
            <div
              key={prop.title}
              className="border border-[#1f1f1f] rounded-lg p-6 bg-[#111111]"
            >
              <h3 className="text-sm font-medium text-[#ededed] mb-2">
                {prop.title}
              </h3>
              <p className="text-sm text-[#999999] leading-relaxed">
                {prop.body}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-[#1f1f1f]">
        <div className="max-w-4xl mx-auto px-6 py-8 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LogoMark size={18} />
            <span className="text-xs text-[#999999]">Stryde</span>
          </div>
          <a href="/privacy" className="text-xs text-[#999999] hover:text-[#999999] transition-colors">
            Privacy Policy
          </a>
        </div>
      </div>

    </div>
  )
}